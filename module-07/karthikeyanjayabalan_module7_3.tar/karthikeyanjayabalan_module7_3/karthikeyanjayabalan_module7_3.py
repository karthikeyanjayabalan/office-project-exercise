"""
this module provides functionality to generate and store sample users in an SQLite database.
It allows you to generate random user records with names, phone numbers, and unique user keys,
and store them in a local SQLite database file.

run the following command to generate 10 random users and store them in the SQLite database:
<docker compose up --build>

run the following command to list the stored users in the SQLite database:
<docker compose run --rm user-store list>

powershell:
Set-Location "<D:\Your\New\Folder>"
New-Item -ItemType Directory -Force -Path .\extracted | Out-Null
tar -xf .\karthikeyanjayabalan_module7_3.tar -C .\extracted
Set-Location .\extracted\karthikeyanjayabalan_module7_3
docker compose -p <module7_3_demo> up --build

cmd: execute following commands 1 by 1
cd /d "<tar folder path>"
mkdir extracted
tar -xf karthikeyanjayabalan_module7_3.tar -C extracted
cd extracted\karthikeyanjayabalan_module7_3
docker compose -p module7_3_demo up --build

docker compose -p module7_3_demo up --build
docker compose -p module7_3_demo run --rm user-store list

command to create a tar file of the module7_3 folder:
tar -cf .\karthikeyanjayabalan_module7_3.tar .\karthikeyanjayabalan_module7_3
tar -tf .\karthikeyanjayabalan_module7_3.tar
"""


import argparse
import os
import random
import secrets
import sqlite3
from contextlib import closing
from pathlib import Path


DB_PATH = Path(os.getenv("DB_PATH", "users.db"))
FIRST_NAMES = (
    "Aarav", "Aditi", "Amara", "Arjun", "David", "Emma", "Fatima", "Grace",
    "Hana", "James", "Karthik", "Liam", "Maya", "Noah", "Priya", "Sofia",
)
LAST_NAMES = (
    "Brown", "Chen", "Garcia", "Iyer", "Johnson", "Khan", "Kumar", "Martin",
    "Patel", "Smith", "Taylor", "Thomas", "Williams", "Wilson", "Wong", "Young",
)


def connect_database() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database() -> None:
    with closing(connect_database()) as connection:
        with connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    user_key TEXT NOT NULL UNIQUE
                )
                """
            )


def generate_users(count: int) -> int:
    if count < 1:
        raise ValueError("count must be at least 1")

    records = [
        (
            f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}",
            f"202-555-01{random.randrange(100):02d}",
            secrets.token_hex(16),
        )
        for _ in range(count)
    ]

    with closing(connect_database()) as connection:
        with connection:
            connection.executemany(
                "INSERT INTO users (name, phone, user_key) VALUES (?, ?, ?)",
                records,
            )

    return count


def print_users() -> int:
    with closing(connect_database()) as connection:
        rows = connection.execute(
            "SELECT id, name, phone, user_key FROM users ORDER BY id"
        ).fetchall()

    if not rows:
        print("No users stored yet.")
        return 0

    print(f"{'ID':<6}{'NAME':<24}{'PHONE':<18}USER_KEY")
    for row in rows:
        print(f"{row['id']:<6}{row['name']:<24}{row['phone']:<18}{row['user_key']}")
    return len(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate and store sample users in SQLite.")
    commands = parser.add_subparsers(dest="command", required=True)

    generate_command = commands.add_parser("generate", help="Generate random user rows")
    generate_command.add_argument("--count", type=int, default=10)
    commands.add_parser("list", help="List stored users")

    args = parser.parse_args()
    initialize_database()

    if args.command == "generate":
        count = generate_users(args.count)
        print(f"Stored {count} random users in {DB_PATH}.")
    else:
        print(f"Users in {DB_PATH}:")
        print_users()


if __name__ == "__main__":
    main()