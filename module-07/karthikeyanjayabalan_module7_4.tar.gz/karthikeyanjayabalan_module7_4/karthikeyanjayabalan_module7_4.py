# CMD.EXE commands (copy the archive to E:\Karthik\11-Projects\DockerTest04 first):
# cd /d E:\Karthik\11-Projects\DockerTest04
# tar -xzf karthikeyanjayabalan_module7_4.tar.gz
# cd karthikeyanjayabalan_module7_4
# py -m venv .venv
# .venv\Scripts\python.exe -m pip install -r requirements.txt pytest
# .venv\Scripts\python.exe -m pytest -q
# docker compose up --build -d
# docker compose ps
# curl.exe -f http://localhost:8000/health
# curl.exe -f -X POST http://localhost:8000/server-info
# docker compose down

from datetime import datetime, timezone
import platform
import socket
import time

import psutil
from fastapi import FastAPI
from fastapi.responses import HTMLResponse


app = FastAPI(title="Server Health API", version="1.0.0")
START_TIME = time.time()


@app.get("/", response_class=HTMLResponse)
def root() -> str:
	return """
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<title>Server Health API</title>
		<style>
			body {
				font-family: Arial, sans-serif;
				margin: 0;
				padding: 40px;
				background: #0f172a;
				color: #e2e8f0;
			}
			.container {
				max-width: 700px;
				margin: 0 auto;
				background: #111827;
				padding: 30px;
				border-radius: 12px;
				box-shadow: 0 8px 24px rgba(0,0,0,0.2);
			}
			a {
				color: #7dd3fc;
				text-decoration: none;
			}
			a:hover {
				text-decoration: underline;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<h1>Server Health API</h1>
			<p>The server is running successfully.</p>
			<ul>
				<li><a href="/docs">Open Swagger Docs</a></li>
				<li><a href="/health">Check health</a></li>
				<li><a href="/server-info">View server info</a></li>
			</ul>
		</div>
	</body>
	</html>
	"""


@app.get("/health")
def health_check() -> dict[str, str]:
	return {"status": "healthy"}


@app.post("/server-info")
def server_info() -> dict[str, str | int | float]:
	memory = psutil.virtual_memory()
	disk = psutil.disk_usage("/")
	current_time = datetime.now(timezone.utc)

	return {
		"status": "healthy",
		"server_name": socket.gethostname(),
		"server_time_utc": current_time.isoformat(),
		"platform": platform.platform(),
		"python_version": platform.python_version(),
		"uptime_seconds": round(time.time() - START_TIME, 2),
		"cpu_usage_percent": psutil.cpu_percent(interval=0.1),
		"cpu_cores": psutil.cpu_count() or 0,
		"memory_usage_percent": memory.percent,
		"memory_total_bytes": memory.total,
		"disk_usage_percent": disk.percent,
		"disk_total_bytes": disk.total,
	}