from fastapi.testclient import TestClient

from karthikeyanjayabalan_module7_4 import app

client = TestClient(app)


def test_root_endpoint() -> None:
    response = client.get("/")
    assert response.status_code == 200
    assert "Server Health API" in response.text
    assert "/docs" in response.text
    assert "/health" in response.text


def test_health_endpoint() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}


def test_server_info_endpoint() -> None:
    response = client.post("/server-info")
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "healthy"
    assert "server_name" in payload
    assert "platform" in payload
    assert "uptime_seconds" in payload
    assert "python_version" in payload
