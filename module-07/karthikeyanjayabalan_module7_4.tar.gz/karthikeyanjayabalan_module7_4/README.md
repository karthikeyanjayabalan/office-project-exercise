# Server Health API

## Start

From this folder, run:

```powershell
docker compose up --build -d
```

To confirm the container is healthy, use:

```powershell
docker compose ps
```

The service should show a status of `healthy` and the app will be available at `http://localhost:8000/docs`.

The `POST /server-info` endpoint returns server health metrics and the current UTC time. `GET /health` is a simple health check.

## Check endpoints manually

```powershell
Invoke-RestMethod -Method Get -Uri "http://localhost:8000/health"
Invoke-RestMethod -Method Post -Uri "http://localhost:8000/server-info"
```

## Call from another computer

Both computers must be on a network that can reach the server. On the server computer, run `ipconfig` and find its LAN IPv4 address. From the other computer, send a POST request to `http://<SERVER_LAN_IP>:8000/server-info`.

PowerShell example:

```powershell
Invoke-RestMethod -Method Post -Uri "http://192.168.1.50:8000/server-info"
```

Replace `192.168.1.50` with the server computer's actual LAN IPv4 address. If the request times out, allow inbound TCP port 8000 through the server computer's firewall. This example has no authentication; use it only on a trusted network and do not expose it directly to the public internet.

Stop the service with `docker compose down`.