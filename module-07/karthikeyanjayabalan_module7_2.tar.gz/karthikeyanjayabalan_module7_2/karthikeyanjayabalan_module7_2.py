"""
# Windows CMD instructions to run this project:
# 1) mkdir "E:\Karthik\11-Projects\DockerTest02"
# 2) copy "E:\Karthik\11-Projects\Home-Projects\karthikeyanjayabalan_module7_2.tar.gz" "E:\Karthik\11-Projects\DockerTest02\"
# 3) cd /d "E:\Karthik\11-Projects\DockerTest02"
# 4) tar -xzf karthikeyanjayabalan_module7_2.tar.gz
# 5) cd /d "E:\Karthik\11-Projects\DockerTest02\karthikeyanjayabalan_module7_2"
# 6) docker compose up --build
# 7) Open: http://localhost:8501
#
# If using local Python directly instead of Docker:
# py -m streamlit run karthikeyanjayabalan_module7_2.py --server.port 8502
#
# This project is a Streamlit app, not a FastAPI app.
"""

import calendar
import ast
import json
import math
import os
import re
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import streamlit as st


OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")
# OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")
# OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "smollm2:135m")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:0.5b")
SYSTEM_PROMPT = (
	"You are a precise, helpful assistant. Answer the user directly. "
	"For arithmetic questions, calculate carefully and give the numeric result first. "
	"Do not provide code unless asked."
)


def _evaluate_arithmetic(node: ast.AST) -> int | float | None:
	if isinstance(node, ast.Constant):
		if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
			return node.value
		return None

	if isinstance(node, ast.UnaryOp):
		value = _evaluate_arithmetic(node.operand)
		if value is None:
			return None
		if isinstance(node.op, ast.UAdd):
			return value
		if isinstance(node.op, ast.USub):
			return -value
		return None

	if isinstance(node, ast.BinOp):
		left = _evaluate_arithmetic(node.left)
		right = _evaluate_arithmetic(node.right)
		if left is None or right is None:
			return None
		try:
			if isinstance(node.op, ast.Add):
				return left + right
			if isinstance(node.op, ast.Sub):
				return left - right
			if isinstance(node.op, ast.Mult):
				return left * right
			if isinstance(node.op, ast.Div):
				return left / right
			if isinstance(node.op, ast.FloorDiv):
				return left // right
			if isinstance(node.op, ast.Mod):
				return left % right
		except ArithmeticError:
			return None
	return None


def _evaluate_expression(expression: str) -> int | float | None:
	if len(expression) > 100:
		return None
	try:
		parsed = ast.parse(expression, mode="eval")
	except SyntaxError:
		return None
	return _evaluate_arithmetic(parsed.body)


def _check_equation(prompt: str) -> str | None:
	if prompt.count("=") != 1:
		return None

	left, right = (part.strip() for part in prompt.split("=", maxsplit=1))
	left_result = _evaluate_expression(left)
	if left_result is None:
		return None

	if right == "?":
		return str(left_result)

	right_result = _evaluate_expression(right)
	if right_result is None:
		return None

	if isinstance(left_result, int) and isinstance(right_result, int):
		is_correct = left_result == right_result
	else:
		try:
			is_correct = math.isclose(
				left_result, right_result, rel_tol=1e-9, abs_tol=1e-9
			)
		except OverflowError:
			is_correct = left_result == right_result

	if is_correct:
		return f"Correct: {left} = {left_result}."
	return f"Incorrect: {left} equals {left_result}, not {right}."


def _check_month_letter_count(prompt: str) -> str | None:
	match = re.search(
		r"\bhow many months\b.*?\bletter\s+['\"]?([a-z])\b",
		prompt,
		re.IGNORECASE,
	)
	if match is None:
		return None

	letter = match.group(1).lower()
	count = sum(letter in month.lower() for month in calendar.month_name[1:])
	month_word = "month" if count == 1 else "months"
	verb = "contains" if count == 1 else "contain"
	return f"{count} {month_word} {verb} the letter '{letter}'."


def ask_ollama(messages: list[dict[str, str]]) -> str:
	request = Request(
		f"{OLLAMA_BASE_URL}/api/chat",
		data=json.dumps(
			{
				"model": OLLAMA_MODEL,
				"messages": [
					{"role": "system", "content": SYSTEM_PROMPT},
					*messages,
				],
				"stream": False,
			}
		).encode("utf-8"),
		headers={"Content-Type": "application/json"},
		method="POST",
	)

	try:
		with urlopen(request, timeout=300) as response:
			result = json.loads(response.read().decode("utf-8"))
	except HTTPError as error:
		detail = error.read().decode("utf-8", errors="replace")
		raise RuntimeError(f"Ollama returned HTTP {error.code}: {detail}") from error
	except URLError as error:
		raise RuntimeError(f"Could not connect to Ollama: {error.reason}") from error

	return result["message"]["content"]


st.set_page_config(page_title="Ollama Chat", page_icon="💬")
st.title("Ollama Chat")
st.caption(f"Model: {OLLAMA_MODEL}")

if "messages" not in st.session_state:
	st.session_state.messages = []

if st.sidebar.button("Clear chat"):
	st.session_state.messages = []
	st.rerun()

for message in st.session_state.messages:
	with st.chat_message(message["role"]):
		st.markdown(message["content"])

prompt = st.chat_input("Ask Ollama something")
if prompt:
	st.session_state.messages.append({"role": "user", "content": prompt})
	with st.chat_message("user"):
		st.markdown(prompt)

	with st.chat_message("assistant"):
		with st.spinner("Ollama is thinking..."):
			try:
				answer = _check_equation(prompt)
				if answer is None:
					answer = _check_month_letter_count(prompt)
				if answer is None:
					answer = ask_ollama(st.session_state.messages)
			except (RuntimeError, KeyError, json.JSONDecodeError) as error:
				st.error(str(error))
			else:
				st.markdown(answer)
				st.session_state.messages.append(
					{"role": "assistant", "content": answer}
				)