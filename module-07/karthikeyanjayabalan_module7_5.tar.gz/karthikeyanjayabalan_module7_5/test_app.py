from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import karthikeyanjayabalan_module7_5 as app_module


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    monkeypatch.setattr(app_module, "DATABASE_PATH", tmp_path / "users.db")
    with TestClient(app_module.app) as test_client:
        yield test_client


def test_root_endpoint(client: TestClient) -> None:
    response = client.get("/")
    assert response.status_code == 200
    assert "Server Health and User Registry" in response.text
    assert "Create random sample" in response.text
    assert "/docs" in response.text


def test_health_endpoint(client: TestClient) -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}


def test_server_info_endpoint(client: TestClient) -> None:
    response = client.post("/server-info")
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "healthy"
    assert "server_name" in payload
    assert "platform" in payload
    assert "uptime_seconds" in payload
    assert "python_version" in payload


def test_create_and_list_user(client: TestClient) -> None:
    payload = {"name": "Avery Reed", "phone": "555-0100", "user_key": "key-1"}
    create_response = client.post("/users", json=payload)

    assert create_response.status_code == 201
    created_user = create_response.json()
    assert created_user == {"id": 1, **payload}

    list_response = client.get("/users")
    assert list_response.status_code == 200
    assert list_response.json() == [created_user]


def test_random_user_is_saved(client: TestClient) -> None:
    response = client.post("/users/random")

    assert response.status_code == 201
    user = response.json()
    assert user["id"] == 1
    assert user["name"]
    assert user["phone"].startswith("+1-555-")
    assert user["user_key"]
    assert client.get("/users").json() == [user]


def test_user_records_persist_between_clients(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(app_module, "DATABASE_PATH", tmp_path / "users.db")
    payload = {"name": "Jordan Hayes", "phone": "555-0199", "user_key": "key-2"}

    with TestClient(app_module.app) as first_client:
        created = first_client.post("/users", json=payload).json()

    with TestClient(app_module.app) as second_client:
        response = second_client.get("/users")

    assert response.status_code == 200
    assert response.json() == [created]
