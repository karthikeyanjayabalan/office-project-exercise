# CMD.EXE commands (copy the archive to E:\Karthik\11-Projects\DockerTest05 first):
# cd /d E:\Karthik\11-Projects\DockerTest05
# tar -xzf karthikeyanjayabalan_module7_5.tar.gz
# cd karthikeyanjayabalan_module7_5
# py -m venv .venv
# .venv\Scripts\python.exe -m pip install -r requirements.txt pytest
# .venv\Scripts\python.exe -m pytest -q
# Expected: 6 passed (a Starlette deprecation warning may appear).
# Ensure Docker Desktop is running before the Docker commands.
# docker volume create karthikeyanjayabalan_module7_data
# docker compose up --build -d
# docker compose ps
# curl.exe -f http://localhost:8000/health
# curl.exe -f http://localhost:8000/users
# curl.exe -f -X POST http://localhost:8000/users/random
# Open http://localhost:8000 in a browser to use the form.
# docker compose down
# Do not remove the external volume if its database records must be kept.

from contextlib import contextmanager
from datetime import datetime, timezone
import os
import platform
import secrets
import socket
import sqlite3
import time
from pathlib import Path
from typing import Iterator

import psutil
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field


DATABASE_PATH = Path(
	os.environ.get(
		"DATABASE_PATH", str(Path(__file__).parent / "data" / "users.db")
	)
)


class UserInput(BaseModel):
	name: str = Field(min_length=1, max_length=100)
	phone: str = Field(min_length=1, max_length=40)
	user_key: str = Field(min_length=1, max_length=200)


class UserRecord(UserInput):
	id: int


@contextmanager
def database_connection() -> Iterator[sqlite3.Connection]:
	DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
	connection = sqlite3.connect(DATABASE_PATH, timeout=10)
	connection.row_factory = sqlite3.Row
	try:
		connection.execute(
			"""
			CREATE TABLE IF NOT EXISTS users (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				name TEXT NOT NULL,
				phone TEXT NOT NULL,
				user_key TEXT NOT NULL
			)
			"""
		)
		yield connection
		connection.commit()
	except Exception:
		connection.rollback()
		raise
	finally:
		connection.close()


def save_user(user: UserInput) -> UserRecord:
	with database_connection() as connection:
		cursor = connection.execute(
			"INSERT INTO users (name, phone, user_key) VALUES (?, ?, ?)",
			(user.name, user.phone, user.user_key),
		)
		row = connection.execute(
			"SELECT id, name, phone, user_key FROM users WHERE id = ?",
			(cursor.lastrowid,),
		).fetchone()
	return UserRecord(**dict(row))


def list_users() -> list[UserRecord]:
	with database_connection() as connection:
		rows = connection.execute(
			"SELECT id, name, phone, user_key FROM users ORDER BY id"
		).fetchall()
	return [UserRecord(**dict(row)) for row in rows]


app = FastAPI(title="Server Health and User Registry API", version="1.0.0")
START_TIME = time.time()


@app.get("/", response_class=HTMLResponse)
def root() -> str:
	return """
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<title>Server Health and User Registry</title>
		<style>
			body {
				font-family: Arial, sans-serif;
				margin: 0;
				padding: 32px 16px;
				background: #f1f5f4;
				color: #18312d;
			}
			.container {
				max-width: 900px;
				margin: 0 auto;
				background: #ffffff;
				padding: 28px;
				border-radius: 8px;
				box-shadow: 0 8px 24px rgba(24, 49, 45, 0.08);
			}
			.form-grid {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
				gap: 14px;
			}
			label {
				display: grid;
				gap: 6px;
				font-size: 14px;
				font-weight: 600;
			}
			input {
				min-width: 0;
				padding: 10px;
				border: 1px solid #a9bbb6;
				border-radius: 4px;
				font: inherit;
			}
			.actions {
				display: flex;
				flex-wrap: wrap;
				gap: 10px;
				margin-top: 16px;
			}
			button {
				padding: 10px 14px;
				border: 0;
				border-radius: 4px;
				background: #146b59;
				color: white;
				font: inherit;
				cursor: pointer;
			}
			button[type="button"] {
				background: #365d72;
			}
			table {
				width: 100%;
				margin-top: 14px;
				border-collapse: collapse;
				text-align: left;
			}
			th, td {
				padding: 10px 8px;
				border-bottom: 1px solid #dce5e2;
				word-break: break-word;
			}
			th {
				background: #eaf2ef;
			}
			.table-wrap {
				overflow-x: auto;
			}
			.navigation {
				margin-top: 22px;
			}
			a {
				color: #146b59;
				text-decoration: none;
			}
			a:hover {
				text-decoration: underline;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<h1>Server Health and User Registry</h1>
			<p>Enter a user record. The database assigns its ID.</p>
			<form id="user-form">
				<div class="form-grid">
					<label>Name<input name="name" maxlength="100" required /></label>
					<label>Phone<input name="phone" maxlength="40" required /></label>
					<label>User key<input name="user_key" maxlength="200" required /></label>
				</div>
				<div class="actions">
					<button type="submit">Save user</button>
					<button type="button" id="random-user">Create random sample</button>
				</div>
			</form>
			<p id="status" role="status" aria-live="polite"></p>
			<h2>Saved users</h2>
			<div class="table-wrap">
				<table>
					<thead><tr><th>ID</th><th>Name</th><th>Phone</th><th>User key</th></tr></thead>
					<tbody id="users"></tbody>
				</table>
			</div>
			<p class="navigation"><a href="/docs">API documentation</a> | <a href="/health">Health check</a></p>
		</div>
		<script>
			const form = document.getElementById("user-form");
			const statusMessage = document.getElementById("status");
			const usersBody = document.getElementById("users");

			async function refreshUsers() {
				const response = await fetch("/users");
				if (!response.ok) throw new Error("Could not load users.");
				const users = await response.json();
				usersBody.replaceChildren();
				for (const user of users) {
					const row = document.createElement("tr");
					for (const value of [user.id, user.name, user.phone, user.user_key]) {
						const cell = document.createElement("td");
						cell.textContent = value;
						row.appendChild(cell);
					}
					usersBody.appendChild(row);
				}
			}

			async function submitUser(user) {
				const response = await fetch("/users", {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify(user)
				});
				const result = await response.json();
				if (!response.ok) throw new Error(result.detail || "Could not save user.");
				statusMessage.textContent = `Saved user with ID ${result.id}.`;
				await refreshUsers();
			}

			form.addEventListener("submit", async (event) => {
				event.preventDefault();
				try {
					await submitUser(Object.fromEntries(new FormData(form)));
					form.reset();
				} catch (error) {
					statusMessage.textContent = error.message;
				}
			});

			document.getElementById("random-user").addEventListener("click", async () => {
				try {
					const response = await fetch("/users/random", { method: "POST" });
					const result = await response.json();
					if (!response.ok) throw new Error(result.detail || "Could not create sample.");
					statusMessage.textContent = `Created random sample with ID ${result.id}.`;
					await refreshUsers();
				} catch (error) {
					statusMessage.textContent = error.message;
				}
			});

			refreshUsers().catch((error) => {
				statusMessage.textContent = error.message;
			});
		</script>
	</body>
	</html>
	"""


@app.post("/users", response_model=UserRecord, status_code=201)
def create_user(user: UserInput) -> UserRecord:
	return save_user(user)


@app.get("/users", response_model=list[UserRecord])
def get_users() -> list[UserRecord]:
	return list_users()


@app.post("/users/random", response_model=UserRecord, status_code=201)
def create_random_user() -> UserRecord:
	first_names = ["Avery", "Jordan", "Morgan", "Taylor", "Riley"]
	last_names = ["Carter", "Reed", "Parker", "Brooks", "Hayes"]
	user = UserInput(
		name=f"{secrets.choice(first_names)} {secrets.choice(last_names)}",
		phone=f"+1-555-{secrets.randbelow(900) + 100}-{secrets.randbelow(10000):04d}",
		user_key=secrets.token_urlsafe(18),
	)
	return save_user(user)


@app.get("/health")
def health_check() -> dict[str, str]:
	return {"status": "healthy"}


@app.post("/server-info")
def server_info() -> dict[str, str | int | float]:
	memory = psutil.virtual_memory()
	disk = psutil.disk_usage("/")
	current_time = datetime.now(timezone.utc)

	return {
		"status": "healthy",
		"server_name": socket.gethostname(),
		"server_time_utc": current_time.isoformat(),
		"platform": platform.platform(),
		"python_version": platform.python_version(),
		"uptime_seconds": round(time.time() - START_TIME, 2),
		"cpu_usage_percent": psutil.cpu_percent(interval=0.1),
		"cpu_cores": psutil.cpu_count() or 0,
		"memory_usage_percent": memory.percent,
		"memory_total_bytes": memory.total,
		"disk_usage_percent": disk.percent,
		"disk_total_bytes": disk.total,
	}