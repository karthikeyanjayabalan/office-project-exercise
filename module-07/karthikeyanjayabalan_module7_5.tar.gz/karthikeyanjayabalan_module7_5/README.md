# Server Health and User Registry

This FastAPI service accepts user records (`name`, `phone`, and `user_key`), assigns each record an integer ID, stores records in SQLite, and retains the existing server-health endpoints. The home page provides a form and a random sample button; API clients can use `/docs`.

## Start with Docker

Create the persistent volume once. If it already exists, Docker reuses it and preserves its database:

```cmd
docker volume create karthikeyanjayabalan_module7_data
```

From this folder, build and start the service:

```cmd
docker compose up --build -d
docker compose ps
```

Open `http://localhost:8000` to enter records or `http://localhost:8000/docs` for the API.

## API endpoints

- `POST /users` creates a user from JSON containing `name`, `phone`, and `user_key`.
- `GET /users` lists stored users.
- `POST /users/random` inserts a randomly generated sample.
- `GET /health` checks service health.
- `POST /server-info` returns server metrics.

Example CMD requests:

```cmd
curl.exe -f -X POST http://localhost:8000/users -H "Content-Type: application/json" -d "{\"name\":\"Avery Reed\",\"phone\":\"555-0100\",\"user_key\":\"sample-key\"}"
curl.exe -f http://localhost:8000/users
curl.exe -f -X POST http://localhost:8000/users/random
```

## Database retention

The database file is stored at `/data/users.db` in the container and mounted from the external Docker volume `karthikeyanjayabalan_module7_data`. Rebuilding or replacing the application image does not replace this volume. `docker compose down` also leaves it intact. Because it is external, Compose will not remove it even with `docker compose down -v`; do not manually remove the volume if its records must be retained.

The 7.4 project did not use a database volume, so there is no 7.4 database to migrate. This creates the persistent database for 7.5 and future updates that reuse the same volume name.

## Tests

With Python and pytest installed, run:

```cmd
python -m pytest -q
```

The API has no authentication and returns the stored `user_key`; use it only on a trusted network, not directly on the public internet.

Stop the service with `docker compose down`. The external database volume remains available for the next start.